class EntryPoint {
  const EntryPoint();
}
